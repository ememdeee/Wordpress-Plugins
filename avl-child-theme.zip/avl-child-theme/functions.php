<?php

add_action('wp_enqueue_scripts', 'remove_google_fonts', 20);
function remove_google_fonts() {
    wp_dequeue_style('open-sans');
    wp_deregister_style('open-sans');
}

// Function to display a message when child theme is activated
function display_child_theme_message() {
    ?>
    <div style="background-color: #f8d7da; color: #721c24; padding: 10px;">
        <p>This is your custom child theme! You can start making your modifications here.</p>
    </div>
    <?php
}
add_action('wp_footer', 'display_child_theme_message');


// remove google font from header
add_action('wp_enqueue_scripts', 'remove_google_fonts', 100);

function remove_google_fonts() {
    wp_dequeue_style('google-fonts-1-css');
}